
import React from 'react';

export const stringToColor = (str: string) => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  const c = (hash & 0x00ffffff).toString(16).toUpperCase();
  return '#' + '00000'.substring(0, 6 - c.length) + c;
};

export const stringToAvatarIndex = (str: string, max: number) => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  return Math.abs(hash) % max;
};

export const compressImage = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 300; 
        const scaleSize = MAX_WIDTH / img.width;
        canvas.width = scaleSize < 1 ? MAX_WIDTH : img.width;
        canvas.height = scaleSize < 1 ? img.height * scaleSize : img.height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.6);
        resolve(dataUrl);
      };
      img.onerror = (err) => reject(err);
    };
    reader.onerror = (err) => reject(err);
  });
};

export const DefaultAvatars = [
  null,
  (className: string) => <svg className={className} style={{width: '100%', height: '100%'}} viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>,
  (className: string) => <svg className={className} style={{width: '100%', height: '100%'}} viewBox="0 0 24 24" fill="currentColor"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>,
  (className: string) => <svg className={className} style={{width: '100%', height: '100%'}} viewBox="0 0 24 24" fill="currentColor"><path d="M12 2c-5.52 0-10 4.48-10 10s4.48 10 10 10 10-4.48 10-10-4.48-10-10-10zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z" /></svg>,
  (className: string) => <svg className={className} style={{width: '100%', height: '100%'}} viewBox="0 0 24 24" fill="currentColor"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z"/></svg>
];

export const SmartAvatar: React.FC<{ name: string; imageUrl?: string; avatarIndex?: number; size?: 'sm' | 'lg' | 'xl'; className?: string }> = ({ name, imageUrl, avatarIndex, size = 'lg', className = '' }) => {
  const sizeClasses = { sm: 'w-10 h-10 text-sm', lg: 'w-24 h-24 text-3xl', xl: 'w-32 h-32 text-5xl' };
  if (imageUrl) return <img src={imageUrl} alt={name} className={`rounded-full object-cover border-4 border-white shadow-lg ${sizeClasses[size]} ${className}`} />;
  const finalIndex = (avatarIndex !== undefined && avatarIndex !== null) ? avatarIndex : stringToAvatarIndex(name, 5);
  const AvatarIcon = DefaultAvatars[finalIndex];
  const bgColor = stringToColor(name);
  if (finalIndex > 0 && AvatarIcon) return <div className={`rounded-full flex items-center justify-center bg-slate-200 text-slate-500 border-4 border-white shadow-lg overflow-hidden ${sizeClasses[size]} ${className}`}>{AvatarIcon("w-2/3 h-2/3")}</div>;
  return <div className={`rounded-full flex items-center justify-center font-black text-white border-4 border-white shadow-lg ${sizeClasses[size]} ${className}`} style={{ backgroundColor: bgColor }}>{name.charAt(0)}</div>;
};
